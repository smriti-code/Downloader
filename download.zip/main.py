from threading import *
from tkinter.filedialog import *
from tkinter.messagebox import *
from tkinter import *

from pytube import YouTube

file_size = 0

# to add percentage
def progress(stream, chunk, bytes_remaining):
    file_downloaded = (file_size - bytes_remaining)
    # print(file_size)
    per = (file_downloaded / file_size) * 100
    B.configure(text="{:00.0f} % Downloaded ".format(per), background="white")

def audio_download():
    try:
        link = url.get()
        if link == "":
            showinfo("ERROR", "PLEASE  ENTER  URL")
        else:
            path = askdirectory()
            B.config(state=DISABLED)
            B1.config(state=DISABLED)
            # can't press button now
            # Changing button text
            B1.configure(text='Loading')
            if path is None:
                return

            y = YouTube(link)
            audio = y.streams.get_audio_only('mp4')  # video is object of list
            audio.download(path)

            print("downloaded")
            # to show message
            showinfo("Downloading status", "Downloaded Successfully")
            B1.configure(text='Download Audio')
            B1.configure(state=NORMAL, bg="grey")
            B.configure(state=NORMAL, bg="grey")
            # to delete the old content
            url.delete(0, END)


    except Exception as e:
        print(e)
        print("error")



def download():
    try:
        global file_size
        B1.config(state=DISABLED)
        link = url.get()
        if link == "":
            showinfo("ERROR", "PLEASE  ENTER  URL")
        else:
            path = askdirectory()
            # Changing button text
            B.configure(text='Loading')
            # can't press button now
            B.config(state=DISABLED)
            if path is None:
                return

            y = YouTube(link)
            y.register_on_progress_callback(progress)
            video = y.streams.first()  # video is object of list
            file_size = video.filesize  # get the total size of file
            video.download(path)
            print("downloaded")
            # to show message
            showinfo("Downloading status", "Downloaded Successfully")
            B.configure(text='Download Video')
            B.configure(state=NORMAL, bg="grey")
            B1.configure(state=NORMAL, bg="grey")
            # to delete the old content
            url.delete(0, END)


    except Exception as e:
        print(e)
        print("error")

# Thread will handel downloading and parent thread handle GUI.. so work fast
def downloader():
    thread = Thread(target=download)
    thread.start()

def downloader1():
    thread = Thread(target=audio_download)
    thread.start()

# GUI
root = Tk()
root.title("DOWNLOADER")
root.iconbitmap('download.ico')
img = PhotoImage(file="download.png")
L = Label(root, image=img, bg="blue")
L1 = Label(root, text="ENTER URL", fg="blue", font="Helvetica 13 bold")
B = Button(root, text="Download Video", command=downloader, width=20, height=2, fg="blue", bg="grey",
           font="Helvetica 17 bold")
B1 = Button(root, text="Download Audio", command=downloader1, width=20, height=2, fg="blue", bg="grey",
           font="Helvetica 17 bold")
url = Entry(root, width=45)

L.pack(side=TOP, pady=20)
L1.pack(padx=8, pady=5, side=TOP)
url.pack(pady=10, side=TOP)
B.pack(pady=20, side=TOP)
B1.pack(pady=20, side=TOP)

root.geometry("450x570")
root.mainloop()
